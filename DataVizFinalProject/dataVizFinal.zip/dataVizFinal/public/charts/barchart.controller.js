'use strict';

angular.module('charts')
    .controller('BarChartController', function ($scope) {
     	
    });
