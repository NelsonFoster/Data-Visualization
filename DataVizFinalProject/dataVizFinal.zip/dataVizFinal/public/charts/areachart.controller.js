'use strict';

angular.module('charts')
    .controller('AreaChartController', function ($scope,$http,$filter) {
      var margin = {top: 20, right: 20, bottom: 30, left: 50},
        width = 960 - margin.left - margin.right,
        height = 500 - margin.top - margin.bottom;

      $scope.charts = {};
      var startD = '2013';
      var endD = '2015';
      $scope.years = {};
       $scope.stockYears = {
         availableOptions: [
           {year: 'all', name: 'ALL'},
           {year: '2013', name: '2013'},
           {year: '2014', name: '2014'},
           {year: '2015', name: '2015'}

         ]
               ,
         selectedOption: {id: $scope.years, name: $scope.years} //This sets the default value of the select in the ui
         };


      init();
      function init() {
        $http.get('/api/areachart', { params:{year:'all'} } )
         .success(function(data) {
           //console.log('coming to the controller:', data);
           $scope.charts = data;
           console.log('value of chart data :', JSON.stringify($scope.charts) );
           callChart();
         })
         .error(function(data) {
           console.log('Error: ' + data);
         });

      }


    $scope.search = function () {
      console.log('date :', $scope.startDate);
      startD = $filter('date')($scope.startDate,'yyyy');
      endD = $filter('date')($scope.endDate,'yyyy');
      console.log('START DATE: ', startD);
      console.log('END DATE: ', endD);
      console.log('YEAR : ', $scope.years.year);
      $http.get('/api/areachart', { params:{year:$scope.years.year} } )
       .success(function(data) {
         //console.log('coming to the controller:', data);
         $scope.charts = data;
         console.log('value of chart data :', JSON.stringify($scope.charts) );
         //callChart();
       })
       .error(function(data) {
         console.log('Error: ' + data);
       });

      callChart();
    }

     function callChart() {

       d3.select("#areachart").select("svg").remove();


       var x = d3.time.scale()
           .range([0, width]);

       var y = d3.scale.linear()
           .range([height, 0]);

       var xAxis = d3.svg.axis()
           .scale(x)
           .orient("bottom");

       var yAxis = d3.svg.axis()
           .scale(y)
           .orient("left");


       var area = d3.svg.area()
           .x(function(d) { return x(d.year); })
           .y0(height)
           .y1(function(d) { return y(d.incidents); });




       var svg = d3.select("#areachart").append("svg")
           .attr("width", width + margin.left + margin.right)
           .attr("height", height + margin.top + margin.bottom)
           .append("g")
           .attr("transform", "translate(" + margin.left + "," + margin.top + ")");




		/*d3.tsv("stockPriceClose.tsv", function(error, data) {
		  if (error) throw error;*/
		var data = $scope.charts;

		data.forEach(function(d) {

		    d.incidents = +d.incidents;
		});

		  x.domain(d3.extent(data, function(d) { return d.year; }));
		  y.domain([0, d3.max(data, function(d) { return d.incidents; })]);

		  svg.append("path")
		      .datum(data)
		      .attr("class", "area")
		      .attr("d", area);

		  svg.append("g")
		      .attr("class", "x axis")
		      .attr("transform", "translate(0," + height + ")")
		      .call(xAxis);



		  svg.append("g")
		      .attr("class", "y axis")
		      .call(yAxis)
		    .append("text")
		      .attr("transform", "rotate(-90)")
		      .attr("y", 6)
		      .attr("dy", ".71em")
		      .style("text-anchor", "end")
		      .text("Incidents");
		/*});*/
     	}
    });
