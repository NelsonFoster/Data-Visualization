'use strict';

angular.module('charts')
    .controller('HighChartLineController', function ($scope,$http) {
      init();
    	function init() {
        serverCall();
      }
    function serverCall() {
        $http.get('/api/highchartline')
          .success(function(data) {
            console.log('coming to the controller:', data);
            $scope.charts = {};
            $scope.charts = data;

            console.log('value of chart data :', $scope.charts);
            callChart();
          })
          .error(function(data) {
            console.log('Error: ' + data);
          });
      }

    function callChart() {
      var year = [];
      var incidents = [];
      $scope.charts.forEach(function(value,key) {
        console.log('value of value :', value);
        year.push(value.year);
        incidents.push(value.incidents);
       });
       console.log('year: ', year);
       console.log('incidents: ', incidents);
       Highcharts.chart('container', {
            chart: {
                type: 'line'
            },

           series: [{
            name: 'Incidents',
            data: incidents
            }],
            title: {
                text: 'Reporting Period'
            },
            xAxis: {
              categories: year
            },
            yAxis: {
                title: {
                    text: 'Number of Offenses'
                }
            }
        });

    }

    });
