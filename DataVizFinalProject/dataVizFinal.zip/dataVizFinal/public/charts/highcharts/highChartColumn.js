'use strict';

angular.module('charts')
    .controller('HighChartController', function ($scope,$http) {
      init();
    	function init() {
        serverCall();
      }
    function serverCall() {
        $http.get('/api/highchartcolumn')
          .success(function(data) {
            console.log('coming to the controller:', data);
            $scope.charts = {};
            $scope.charts = data;

            console.log('value of chart data :', $scope.charts);
            callChart();
          })
          .error(function(data) {
            console.log('Error: ' + data);
          });
      }

    function callChart() {
      var offense = [];
      var incidents = [];
      $scope.charts.forEach(function(value,key) {
        console.log('value of value :', value);
        offense.push(value.offense);
        incidents.push(value.incidents);
       });
       console.log('offense: ', offense);
       console.log('incidents: ', incidents);
       Highcharts.chart('container', {
            chart: {
                type: 'column'
            },
            series: [{
            name: 'Incidents',
            data: incidents
            }],
            title: {
                text: 'Number of Campus Incidents by Offense Type, 2013-2015'
            },
            xAxis: {
              categories: offense
            },
            yAxis: {
                title: {
                    text: 'Offense'
                }
            }
        });

    }


    });
