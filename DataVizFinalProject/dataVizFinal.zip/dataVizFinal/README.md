go to the directory where server.js is there.

run the following commands

npm init

npm install express fs mysql morgan body-parser method-override

node server.js
