CREATE DATABASE  IF NOT EXISTS `campusCrime` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `campusCrime`;
-- MySQL dump 10.13  Distrib 5.7.17, for macos10.12 (x86_64)
--
-- Host: 127.0.0.1    Database: campusCrime
-- ------------------------------------------------------
-- Server version	5.7.17

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `campuscrime`
--

DROP TABLE IF EXISTS `campuscrime`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `campuscrime` (
  `sector` text,
  `offense` text,
  `year` int(11) DEFAULT NULL,
  `incidents` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `campuscrime`
--

LOCK TABLES `campuscrime` WRITE;
/*!40000 ALTER TABLE `campuscrime` DISABLE KEYS */;
INSERT INTO `campuscrime` VALUES ('Public, 4-year or above','Murder',2013,16),('Private nonprofit, 4-year or above','Murder',2013,13),('Private for-profit, 4-year or above','Murder',2013,3),('Public, 2-year','Murder',2013,8),('Private nonprofit, 2-year','Murder',2013,1),('Private for-profit, 2-year','Murder',2013,0),('Public, less-than 2-year','Murder',2013,0),('Private nonprofit, less-than 2-year','Murder',2013,0),('Private for-profit, less-than 2-year','Murder',2013,1),('Public, 4-year or above','Murder',2014,8),('Private nonprofit, 4-year or above','Murder',2014,13),('Private for-profit, 4-year or above','Murder',2014,3),('Public, 2-year','Murder',2014,5),('Private nonprofit, 2-year','Murder',2014,0),('Private for-profit, 2-year','Murder',2014,1),('Public, less-than 2-year','Murder',2014,0),('Private nonprofit, less-than 2-year','Murder',2014,0),('Private for-profit, less-than 2-year','Murder',2014,2),('Public, 4-year or above','Murder',2015,24),('Private nonprofit, 4-year or above','Murder',2015,9),('Private for-profit, 4-year or above','Murder',2015,2),('Public, 2-year','Murder',2015,14),('Private nonprofit, 2-year','Murder',2015,0),('Private for-profit, 2-year','Murder',2015,0),('Public, less-than 2-year','Murder',2015,0),('Private nonprofit, less-than 2-year','Murder',2015,0),('Private for-profit, less-than 2-year','Murder',2015,0),('Public, 4-year or above','Rape',2014,2550),('Private nonprofit, 4-year or above','Rape',2014,2376),('Private for-profit, 4-year or above','Rape',2014,51),('Public, 2-year','Rape',2014,170),('Private nonprofit, 2-year','Rape',2014,9),('Private for-profit, 2-year','Rape',2014,18),('Public, less-than 2-year','Rape',2014,2),('Private nonprofit, less-than 2-year','Rape',2014,0),('Private for-profit, less-than 2-year','Rape',2014,10),('Public, 4-year or above','Rape',2015,2965),('Private nonprofit, 4-year or above','Rape',2015,2602),('Private for-profit, 4-year or above','Rape',2015,23),('Public, 2-year','Rape',2015,246),('Private nonprofit, 2-year','Rape',2015,4),('Private for-profit, 2-year','Rape',2015,11),('Public, less-than 2-year','Rape',2015,8),('Private nonprofit, less-than 2-year','Rape',2015,0),('Private for-profit, less-than 2-year','Rape',2015,12),('Public, 4-year or above','Robbery',2013,623),('Private nonprofit, 4-year or above','Robbery',2013,773),('Private for-profit, 4-year or above','Robbery',2013,59),('Public, 2-year','Robbery',2013,213),('Private nonprofit, 2-year','Robbery',2013,24),('Private for-profit, 2-year','Robbery',2013,79),('Public, less-than 2-year','Robbery',2013,5),('Private nonprofit, less-than 2-year','Robbery',2013,11),('Private for-profit, less-than 2-year','Robbery',2013,121),('Public, 4-year or above','Robbery',2014,524),('Private nonprofit, 4-year or above','Robbery',2014,646),('Private for-profit, 4-year or above','Robbery',2014,76),('Public, 2-year','Robbery',2014,188),('Private nonprofit, 2-year','Robbery',2014,36),('Private for-profit, 2-year','Robbery',2014,84),('Public, less-than 2-year','Robbery',2014,9),('Private nonprofit, less-than 2-year','Robbery',2014,8),('Private for-profit, less-than 2-year','Robbery',2014,113),('Public, 4-year or above','Robbery',2015,509),('Private nonprofit, 4-year or above','Robbery',2015,669),('Private for-profit, 4-year or above','Robbery',2015,59),('Public, 2-year','Robbery',2015,154),('Private nonprofit, 2-year','Robbery',2015,8),('Private for-profit, 2-year','Robbery',2015,71),('Public, less-than 2-year','Robbery',2015,7),('Private nonprofit, less-than 2-year','Robbery',2015,3),('Private for-profit, less-than 2-year','Robbery',2015,135),('Public, 4-year or above','Assault',2013,449),('Private nonprofit, 4-year or above','Assault',2013,440),('Private for-profit, 4-year or above','Assault',2013,54),('Public, 2-year','Assault',2013,198),('Private nonprofit, 2-year','Assault',2013,26),('Private for-profit, 2-year','Assault',2013,65),('Public, less-than 2-year','Assault',2013,7),('Private nonprofit, less-than 2-year','Assault',2013,7),('Private for-profit, less-than 2-year','Assault',2013,76),('Public, 4-year or above','Assault',2014,389),('Private nonprofit, 4-year or above','Assault',2014,410),('Private for-profit, 4-year or above','Assault',2014,37),('Public, 2-year','Assault',2014,156),('Private nonprofit, 2-year','Assault',2014,31),('Private for-profit, 2-year','Assault',2014,75),('Public, less-than 2-year','Assault',2014,2),('Private nonprofit, less-than 2-year','Assault',2014,1),('Private for-profit, less-than 2-year','Assault',2014,90),('Public, 4-year or above','Assault',2015,391),('Private nonprofit, 4-year or above','Assault',2015,474),('Private for-profit, 4-year or above','Assault',2015,41),('Public, 2-year','Assault',2015,186),('Private nonprofit, 2-year','Assault',2015,13),('Private for-profit, 2-year','Assault',2015,60),('Public, less-than 2-year','Assault',2015,9),('Private nonprofit, less-than 2-year','Assault',2015,4),('Private for-profit, less-than 2-year','Assault',2015,75),('Public, 4-year or above','Burglary',2013,8144),('Private nonprofit, 4-year or above','Burglary',2013,6540),('Private for-profit, 4-year or above','Burglary',2013,420),('Public, 2-year','Burglary',2013,1733),('Private nonprofit, 2-year','Burglary',2013,86),('Private for-profit, 2-year','Burglary',2013,103),('Public, less-than 2-year','Burglary',2013,36),('Private nonprofit, less-than 2-year','Burglary',2013,20),('Private for-profit, less-than 2-year','Burglary',2013,121),('Public, 4-year or above','Burglary',2014,7593),('Private nonprofit, 4-year or above','Burglary',2014,5568),('Private for-profit, 4-year or above','Burglary',2014,349),('Public, 2-year','Burglary',2014,1560),('Private nonprofit, 2-year','Burglary',2014,72),('Private for-profit, 2-year','Burglary',2014,71),('Public, less-than 2-year','Burglary',2014,18),('Private nonprofit, less-than 2-year','Burglary',2014,22),('Private for-profit, less-than 2-year','Burglary',2014,104),('Public, 4-year or above','Burglary',2015,6542),('Private nonprofit, 4-year or above','Burglary',2015,5322),('Private for-profit, 4-year or above','Burglary',2015,223),('Public, 2-year','Burglary',2015,1494),('Private nonprofit, 2-year','Burglary',2015,76),('Private for-profit, 2-year','Burglary',2015,75),('Public, less-than 2-year','Burglary',2015,16),('Private nonprofit, less-than 2-year','Burglary',2015,37),('Private for-profit, less-than 2-year','Burglary',2015,95),('Public, 4-year or above','VehicleTheft',2013,459),('Private nonprofit, 4-year or above','VehicleTheft',2013,535),('Private for-profit, 4-year or above','VehicleTheft',2013,116),('Public, 2-year','VehicleTheft',2013,195),('Private nonprofit, 2-year','VehicleTheft',2013,13),('Private for-profit, 2-year','VehicleTheft',2013,98),('Public, less-than 2-year','VehicleTheft',2013,12),('Private nonprofit, less-than 2-year','VehicleTheft',2013,8),('Private for-profit, less-than 2-year','VehicleTheft',2013,132),('Public, 4-year or above','VehicleTheft',2014,410),('Private nonprofit, 4-year or above','VehicleTheft',2014,507),('Private for-profit, 4-year or above','VehicleTheft',2014,60),('Public, 2-year','VehicleTheft',2014,170),('Private nonprofit, 2-year','VehicleTheft',2014,17),('Private for-profit, 2-year','VehicleTheft',2014,97),('Public, less-than 2-year','VehicleTheft',2014,11),('Private nonprofit, less-than 2-year','VehicleTheft',2014,7),('Private for-profit, less-than 2-year','VehicleTheft',2014,103),('Public, 4-year or above','VehicleTheft',2015,495),('Private nonprofit, 4-year or above','VehicleTheft',2015,473),('Private for-profit, 4-year or above','VehicleTheft',2015,41),('Public, 2-year','VehicleTheft',2015,178),('Private nonprofit, 2-year','VehicleTheft',2015,5),('Private for-profit, 2-year','VehicleTheft',2015,78),('Public, less-than 2-year','VehicleTheft',2015,4),('Private nonprofit, less-than 2-year','VehicleTheft',2015,5),('Private for-profit, less-than 2-year','VehicleTheft',2015,103),('Public, 4-year or above','Arson',2013,460),('Private nonprofit, 4-year or above','Arson',2013,200),('Private for-profit, 4-year or above','Arson',2013,5),('Public, 2-year','Arson',2013,55),('Private nonprofit, 2-year','Arson',2013,0),('Private for-profit, 2-year','Arson',2013,3),('Public, less-than 2-year','Arson',2013,3),('Private nonprofit, less-than 2-year','Arson',2013,0),('Private for-profit, less-than 2-year','Arson',2013,5),('Public, 4-year or above','Arson',2014,410),('Private nonprofit, 4-year or above','Arson',2014,210),('Private for-profit, 4-year or above','Arson',2014,3),('Public, 2-year','Arson',2014,65),('Private nonprofit, 2-year','Arson',2014,0),('Private for-profit, 2-year','Arson',2014,2),('Public, less-than 2-year','Arson',2014,2),('Private nonprofit, less-than 2-year','Arson',2014,0),('Private for-profit, less-than 2-year','Arson',2014,2),('Public, 4-year or above','Arson',2015,342),('Private nonprofit, 4-year or above','Arson',2015,247),('Private for-profit, 4-year or above','Arson',2015,3),('Public, 2-year','Arson',2015,74),('Private nonprofit, 2-year','Arson',2015,3),('Private for-profit, 2-year','Arson',2015,2),('Public, less-than 2-year','Arson',2015,3),('Private nonprofit, less-than 2-year','Arson',2015,0),('Private for-profit, less-than 2-year','Arson',2015,3),('Public, 4-year or above','IllegalWeaponPossession',2013,634),('Private nonprofit, 4-year or above','IllegalWeaponPossession',2013,572),('Private for-profit, 4-year or above','IllegalWeaponPossession',2013,29),('Public, 2-year','IllegalWeaponPossession',2013,262),('Private nonprofit, 2-year','IllegalWeaponPossession',2013,14),('Private for-profit, 2-year','IllegalWeaponPossession',2013,4),('Public, less-than 2-year','IllegalWeaponPossession',2013,97),('Private nonprofit, less-than 2-year','IllegalWeaponPossession',2013,1),('Private for-profit, less-than 2-year','IllegalWeaponPossession',2013,21),('Public, 4-year or above','IllegalWeaponPossession',2014,674),('Private nonprofit, 4-year or above','IllegalWeaponPossession',2014,523),('Private for-profit, 4-year or above','IllegalWeaponPossession',2014,25),('Public, 2-year','IllegalWeaponPossession',2014,297),('Private nonprofit, 2-year','IllegalWeaponPossession',2014,18),('Private for-profit, 2-year','IllegalWeaponPossession',2014,2),('Public, less-than 2-year','IllegalWeaponPossession',2014,104),('Private nonprofit, less-than 2-year','IllegalWeaponPossession',2014,0),('Private for-profit, less-than 2-year','IllegalWeaponPossession',2014,21),('Public, 4-year or above','IllegalWeaponPossession',2015,603),('Private nonprofit, 4-year or above','IllegalWeaponPossession',2015,611),('Private for-profit, 4-year or above','IllegalWeaponPossession',2015,24),('Public, 2-year','IllegalWeaponPossession',2015,295),('Private nonprofit, 2-year','IllegalWeaponPossession',2015,3),('Private for-profit, 2-year','IllegalWeaponPossession',2015,5),('Public, less-than 2-year','IllegalWeaponPossession',2015,66),('Private nonprofit, less-than 2-year','IllegalWeaponPossession',2015,0),('Private for-profit, less-than 2-year','IllegalWeaponPossession',2015,21),('Public, 4-year or above','DrugArrests',2013,29220),('Private nonprofit, 4-year or above','DrugArrests',2013,24270),('Private for-profit, 4-year or above','DrugArrests',2013,785),('Public, 2-year','DrugArrests',2013,2424),('Private nonprofit, 2-year','DrugArrests',2013,180),('Private for-profit, 2-year','DrugArrests',2013,136),('Public, less-than 2-year','DrugArrests',2013,276),('Private nonprofit, less-than 2-year','DrugArrests',2013,1),('Private for-profit, less-than 2-year','DrugArrests',2013,333),('Public, 4-year or above','DrugArrests',2014,31228),('Private nonprofit, 4-year or above','DrugArrests',2014,24912),('Private for-profit, 4-year or above','DrugArrests',2014,574),('Public, 2-year','DrugArrests',2014,2656),('Private nonprofit, 2-year','DrugArrests',2014,201),('Private for-profit, 2-year','DrugArrests',2014,166),('Public, less-than 2-year','DrugArrests',2014,304),('Private nonprofit, less-than 2-year','DrugArrests',2014,2),('Private for-profit, less-than 2-year','DrugArrests',2014,211),('Public, 4-year or above','DrugArrests',2015,31268),('Private nonprofit, 4-year or above','DrugArrests',2015,23526),('Private for-profit, 4-year or above','DrugArrests',2015,505),('Public, 2-year','DrugArrests',2015,2714),('Private nonprofit, 2-year','DrugArrests',2015,235),('Private for-profit, 2-year','DrugArrests',2015,215),('Public, less-than 2-year','DrugArrests',2015,220),('Private nonprofit, less-than 2-year','DrugArrests',2015,1),('Private for-profit, less-than 2-year','DrugArrests',2015,257),('Public, 4-year or above','LiquorLawViolations',2013,101323),('Private nonprofit, 4-year or above','LiquorLawViolations',2013,92754),('Private for-profit, 4-year or above','LiquorLawViolations',2013,877),('Public, 2-year','LiquorLawViolations',2013,4869),('Private nonprofit, 2-year','LiquorLawViolations',2013,293),('Private for-profit, 2-year','LiquorLawViolations',2013,145),('Public, less-than 2-year','LiquorLawViolations',2013,87),('Private nonprofit, less-than 2-year','LiquorLawViolations',2013,0),('Private for-profit, less-than 2-year','LiquorLawViolations',2013,211),('Public, 4-year or above','LiquorLawViolations',2014,106270),('Private nonprofit, 4-year or above','LiquorLawViolations',2014,92146),('Private for-profit, 4-year or above','LiquorLawViolations',2014,773),('Public, 2-year','LiquorLawViolations',2014,4795),('Private nonprofit, 2-year','LiquorLawViolations',2014,468),('Private for-profit, 2-year','LiquorLawViolations',2014,251),('Public, less-than 2-year','LiquorLawViolations',2014,167),('Private nonprofit, less-than 2-year','LiquorLawViolations',2014,0),('Private for-profit, less-than 2-year','LiquorLawViolations',2014,149),('Public, 4-year or above','LiquorLawViolations',2015,98581),('Private nonprofit, 4-year or above','LiquorLawViolations',2015,87499),('Private for-profit, 4-year or above','LiquorLawViolations',2015,649),('Public, 2-year','LiquorLawViolations',2015,4676),('Private nonprofit, 2-year','LiquorLawViolations',2015,364),('Private for-profit, 2-year','LiquorLawViolations',2015,132),('Public, less-than 2-year','LiquorLawViolations',2015,142),('Private nonprofit, less-than 2-year','LiquorLawViolations',2015,0),('Private for-profit, less-than 2-year','LiquorLawViolations',2015,163),('Public, 4-year or above','DomesticViolence',2014,1993),('Private nonprofit, 4-year or above','DomesticViolence',2014,959),('Private for-profit, 4-year or above','DomesticViolence',2014,142),('Public, 2-year','DomesticViolence',2014,622),('Private nonprofit, 2-year','DomesticViolence',2014,45),('Private for-profit, 2-year','DomesticViolence',2014,54),('Public, less-than 2-year','DomesticViolence',2014,4),('Private nonprofit, less-than 2-year','DomesticViolence',2014,4),('Private for-profit, less-than 2-year','DomesticViolence',2014,84),('Public, 4-year or above','DomesticViolence',2015,2277),('Private nonprofit, 4-year or above','DomesticViolence',2015,1101),('Private for-profit, 4-year or above','DomesticViolence',2015,102),('Public, 2-year','DomesticViolence',2015,728),('Private nonprofit, 2-year','DomesticViolence',2015,26),('Private for-profit, 2-year','DomesticViolence',2015,48),('Public, less-than 2-year','DomesticViolence',2015,51),('Private nonprofit, less-than 2-year','DomesticViolence',2015,3),('Private for-profit, less-than 2-year','DomesticViolence',2015,94),('Public, 4-year or above','DatingViolence',2014,1913),('Private nonprofit, 4-year or above','DatingViolence',2014,1231),('Private for-profit, 4-year or above','DatingViolence',2014,53),('Public, 2-year','DatingViolence',2014,349),('Private nonprofit, 2-year','DatingViolence',2014,20),('Private for-profit, 2-year','DatingViolence',2014,20),('Public, less-than 2-year','DatingViolence',2014,5),('Private nonprofit, less-than 2-year','DatingViolence',2014,0),('Private for-profit, less-than 2-year','DatingViolence',2014,2),('Public, 4-year or above','DatingViolence',2015,2377),('Private nonprofit, 4-year or above','DatingViolence',2015,1449),('Private for-profit, 4-year or above','DatingViolence',2015,30),('Public, 2-year','DatingViolence',2015,447),('Private nonprofit, 2-year','DatingViolence',2015,4),('Private for-profit, 2-year','DatingViolence',2015,11),('Public, less-than 2-year','DatingViolence',2015,3),('Private nonprofit, less-than 2-year','DatingViolence',2015,2),('Private for-profit, less-than 2-year','DatingViolence',2015,13),('Public, 4-year or above','Stalking',2014,2363),('Private nonprofit, 4-year or above','Stalking',2014,1394),('Private for-profit, 4-year or above','Stalking',2014,69),('Public, 2-year','Stalking',2014,728),('Private nonprofit, 2-year','Stalking',2014,18),('Private for-profit, 2-year','Stalking',2014,29),('Public, less-than 2-year','Stalking',2014,6),('Private nonprofit, less-than 2-year','Stalking',2014,3),('Private for-profit, less-than 2-year','Stalking',2014,17),('Public, 4-year or above','Stalking',2015,3150),('Private nonprofit, 4-year or above','Stalking',2015,1776),('Private for-profit, 4-year or above','Stalking',2015,67),('Public, 2-year','Stalking',2015,882),('Private nonprofit, 2-year','Stalking',2015,8),('Private for-profit, 2-year','Stalking',2015,28),('Public, less-than 2-year','Stalking',2015,8),('Private nonprofit, less-than 2-year','Stalking',2015,0),('Private for-profit, less-than 2-year','Stalking',2015,34);
/*!40000 ALTER TABLE `campuscrime` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `incidentspersector`
--

DROP TABLE IF EXISTS `incidentspersector`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `incidentspersector` (
  `Sector` text,
  `2013 Academic Year` int(11) DEFAULT NULL,
  `2014 Academic Year` int(11) DEFAULT NULL,
  `2015 Academic Year` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `incidentspersector`
--

LOCK TABLES `incidentspersector` WRITE;
/*!40000 ALTER TABLE `incidentspersector` DISABLE KEYS */;
INSERT INTO `incidentspersector` VALUES ('Private for-profit, 2-year',633,870,736),('Private for-profit, 4-year or above',2348,2215,1769),('Private for-profit, less-than 2-year',1021,908,1005),('Private nonprofit, 2-year',637,935,749),('Private nonprofit, 4-year or above',126097,130895,125758),('Private nonprofit, less-than 2-year',48,47,55),('Public, 2-year',9957,11761,12088),('Public, 4-year or above',141328,156325,149524),('Public, less-than 2-year',523,634,537);
/*!40000 ALTER TABLE `incidentspersector` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `incidentsperyear`
--

DROP TABLE IF EXISTS `incidentsperyear`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `incidentsperyear` (
  `year` int(11) DEFAULT NULL,
  `incidents` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `incidentsperyear`
--

LOCK TABLES `incidentsperyear` WRITE;
/*!40000 ALTER TABLE `incidentsperyear` DISABLE KEYS */;
INSERT INTO `incidentsperyear` VALUES (2013,282592),(2014,304590),(2015,292221);
/*!40000 ALTER TABLE `incidentsperyear` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `offensesbytype`
--

DROP TABLE IF EXISTS `offensesbytype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `offensesbytype` (
  `offense` text,
  `incidents` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `offensesbytype`
--

LOCK TABLES `offensesbytype` WRITE;
/*!40000 ALTER TABLE `offensesbytype` DISABLE KEYS */;
INSERT INTO `offensesbytype` VALUES ('Arson',2102),('Assault',3766),('Burglary',46440),('DatingViolence',7929),('DomesticViolence',8337),('DrugArrests',176820),('IllegalWeaponPossession',4926),('LiquorLawViolations',597784),('Murder',123),('Rape',11057),('Robbery',5207),('Stalking',10580),('VehicleTheft',4332);
/*!40000 ALTER TABLE `offensesbytype` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `offensesperyear`
--

DROP TABLE IF EXISTS `offensesperyear`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `offensesperyear` (
  `year` int(11) DEFAULT NULL,
  `Arson` int(11) DEFAULT NULL,
  `Assault` int(11) DEFAULT NULL,
  `Burglary` int(11) DEFAULT NULL,
  `DatingViolence` text,
  `DomesticViolence` text,
  `DrugArrests` int(11) DEFAULT NULL,
  `IllegalWeaponPossession` int(11) DEFAULT NULL,
  `LiquorLawViolations` int(11) DEFAULT NULL,
  `Murder` int(11) DEFAULT NULL,
  `Rape` text,
  `Robbery` int(11) DEFAULT NULL,
  `Stalking` text,
  `VehicleTheft` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `offensesperyear`
--

LOCK TABLES `offensesperyear` WRITE;
/*!40000 ALTER TABLE `offensesperyear` DISABLE KEYS */;
INSERT INTO `offensesperyear` VALUES (2013,731,1322,17203,'','',57625,1634,200559,42,'',1908,'',1568),(2014,694,1191,15357,'3593','3907',60254,1664,205019,32,'5186',1684,'4627',1382),(2015,677,1253,13880,'4336','4430',58941,1628,192206,49,'5871',1615,'5953',1382);
/*!40000 ALTER TABLE `offensesperyear` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `violencebysector`
--

DROP TABLE IF EXISTS `violencebysector`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `violencebysector` (
  `sector` text,
  `Arson` int(11) DEFAULT NULL,
  `Assault` int(11) DEFAULT NULL,
  `Burglary` int(11) DEFAULT NULL,
  `DatingViolence` int(11) DEFAULT NULL,
  `DomesticViolence` int(11) DEFAULT NULL,
  `DrugArrests` int(11) DEFAULT NULL,
  `IllegalWeaponPossession` int(11) DEFAULT NULL,
  `LiquorLawViolations` int(11) DEFAULT NULL,
  `Murder` int(11) DEFAULT NULL,
  `Rape` int(11) DEFAULT NULL,
  `Robbery` int(11) DEFAULT NULL,
  `Stalking` int(11) DEFAULT NULL,
  `VehicleTheft` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `violencebysector`
--

LOCK TABLES `violencebysector` WRITE;
/*!40000 ALTER TABLE `violencebysector` DISABLE KEYS */;
INSERT INTO `violencebysector` VALUES ('Private for-profit, 2-year',7,200,249,31,102,517,11,528,1,29,234,57,273),('Private for-profit, 4-year or above',11,132,992,83,244,1864,78,2299,8,74,194,136,217),('Private for-profit, less-than 2-year',10,241,320,15,178,801,63,523,3,22,369,51,338),('Private nonprofit, 2-year',3,70,234,24,71,616,35,1125,1,13,68,26,35),('Private nonprofit, 4-year or above',657,1324,17430,2680,2060,72708,1706,272399,35,4978,2088,3170,1515),('Private nonprofit, less-than 2-year',0,12,79,2,7,4,1,0,0,0,22,3,20),('Public, 2-year',194,540,4787,796,1350,7794,854,14340,27,416,555,1610,543),('Public, 4-year or above',1212,1229,22279,4290,4270,91716,1911,306174,48,5515,1656,5513,1364),('Public, less-than 2-year',8,18,70,8,55,800,267,396,0,10,21,14,27);
/*!40000 ALTER TABLE `violencebysector` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-12-19 23:33:56
